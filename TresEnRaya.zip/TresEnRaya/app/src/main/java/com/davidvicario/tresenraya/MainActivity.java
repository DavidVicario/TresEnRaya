package com.davidvicario.tresenraya;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Arrays;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private Integer boton [];
    private int tablero [] = new int[]{
            0, 0, 0,
            0, 0, 0,
            0, 0, 0
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Ocultar barra de aplicaciones
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        final TextView textV = findViewById(R.id.text1);
        textV.setVisibility(View.INVISIBLE);

        boton = new Integer []{
                R.id.Boton1, R.id.Boton2, R.id.Boton3,
                R.id.Boton4, R.id.Boton5, R.id.Boton6,
                R.id.Boton7, R.id.Boton8, R.id.Boton9,
        };
    }

    public void jugador(View v){
        int nBoton = Arrays.asList(boton).indexOf(v.getId());


    }

    public void jugIA(){
        Random ran = new Random();
    }


}